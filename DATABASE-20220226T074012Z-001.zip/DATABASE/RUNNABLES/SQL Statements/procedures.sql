--------------------------------------------------------
--  File created - Sunday-March-08-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure ADDBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."ADDBOOK" (l_isbn VARCHAR2, l_title VARCHAR2, l_author VARCHAR2, l_year NUMBER, l_shelf NUMBER) AS

l_check NUMBER;
l_check2 NUMBER;
l_check3 NUMBER;
l_quantity NUMBER;
l_capacity NUMBER;
l_copy NUMBER;
  
BEGIN


SELECT COUNT(shelf_id) into l_check FROM shelf where shelf_id = l_shelf;

SELECT quantity, capacity into l_quantity, l_capacity FROM SHELF where shelf_id = l_shelf;

IF l_quantity = l_capacity THEN
  RAISE_APPLICATION_ERROR(-20111, 'Storage Exceeded'); 
ELSIF l_check = 0 THEN
  RAISE_APPLICATION_ERROR(-20121, 'Shelf ID does not Exits'); 
ELSE

  SELECT COUNT(isbn_number) into l_copy FROM book where isbn_number = l_isbn;

  IF l_copy = 0 THEN
    INSERT INTO BOOK VALUES (l_isbn,l_title,l_year, 1 ,'On Shelf',null,l_shelf,'NA',author_id_sequence.nextval);
  
    SELECT COUNT(author_name) into l_check2 FROM AUTHOR WHERE author_name = l_author;
    IF l_check2 = 0 THEN
      INSERT INTO AUTHOR VALUES (author_id_sequence.currval, l_author);
    END IF;
  ELSE
    UPDATE BOOK
    SET copy_number = copy_number + 1
    WHERE isbn_number = l_isbn;
  END IF;
  
  SELECT shelf_id into l_check3 FROM book where isbn_number = l_isbn;
  
  UPDATE SHELF
  SET Quantity = Quantity + 1
  WHERE SHELF_ID = l_check3;
END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20112, 'ERROR'); 

END;

/
--------------------------------------------------------
--  DDL for Procedure ADDSHELF
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."ADDSHELF" (l_cap NUMBER) AS

BEGIN

INSERT INTO SHELF VALUES (shelf_id_sequence.nextval, l_cap, 0);

END;

/
--------------------------------------------------------
--  DDL for Procedure DELETEBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."DELETEBOOK" (l_isbn VARCHAR2) AS

l_shelf NUMBER;
l_copy NUMBER;
l_check NUMBER;

BEGIN

select COUNT(isbn_number) into l_check FROM book where isbn_number = l_isbn;
if l_check != 0 THEN

  select shelf_id into l_shelf FROM book where isbn_number = l_isbn;

  UPDATE BOOK
  SET copy_number = copy_number-1
  WHERE isbn_number = l_isbn;

  select copy_number into l_copy FROM book where isbn_number = l_isbn;

  if l_copy = 0 THEN
  delete from book where isbn_number = l_isbn;
  end if;

  UPDATE SHELF
  SET Quantity = Quantity - 1
  WHERE SHELF_ID = l_shelf;
  
ELSE

  RAISE_APPLICATION_ERROR(-20222, 'ISBN_NUMBER DOES NOT EXIST'); 

END IF;

END;

/
--------------------------------------------------------
--  DDL for Procedure EDITADDRESS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITADDRESS" (l_add VARCHAR2, l_id NUMBER) AS 
BEGIN
UPDATE USERS
SET user_address = l_add
WHERE user_id = l_id;
END;

/
--------------------------------------------------------
--  DDL for Procedure EDITBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITBOOK" (l_isbn VARCHAR2, l_title VARCHAR2, l_author VARCHAR2, l_year VARCHAR2) AS

l_check NUMBER;

BEGIN

UPDATE BOOK
SET book_title = l_title,
    year_published = l_year
WHERE ISBN_NUMBER = l_isbn;


SELECT COUNT(author_name) into l_check FROM AUTHOR WHERE author_name = l_author;

IF l_check = 0 THEN
INSERT INTO AUTHOR VALUES (author_id_sequence.nextval, l_author);
END IF;

END;

/
--------------------------------------------------------
--  DDL for Procedure EDITNAME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITNAME" (l_name VARCHAR2, l_id NUMBER) AS 
BEGIN
UPDATE USERS
SET user_name = l_name
WHERE user_id = l_id;
END;

/
--------------------------------------------------------
--  DDL for Procedure EDITPASS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITPASS" (l_pass VARCHAR2, l_id NUMBER) AS 
BEGIN
UPDATE USERS
SET user_password = l_pass
WHERE user_id = l_id;
END;

/
