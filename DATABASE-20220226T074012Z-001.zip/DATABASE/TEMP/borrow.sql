--------------------------------------------------------
--  File created - Monday-March-09-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure BORROWBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."BORROWBOOK" (l_user_id NUMBER, l_isbn VARCHAR2) AS

l_user NUMBER;
l_txn NUMBER;
l_patisbn NUMBER;
l_patisbn2 NUMBER;
l_book NUMBER;
l_book2 NUMBER;
l_check NUMBER;

BEGIN

SELECT count(user_id) into l_user from patron where user_id = l_user_id and txn_id is not null;

if l_user = 0 THEN
INSERT INTO TRANSACTIONS VALUES(txn_id_sequence.nextval,l_isbn,null,'ON HOLD',null,SYSDATE,null,SYSDATE+7,null,0,0);
UPDATE PATRON
SET TXN_ID = txn_id_sequence.currval,
  isbn_number = null,
  isbn_number2 = null
WHERE l_user_id = user_id;
end if;

select count(isbn_number) into  l_patisbn from patron where user_id = l_user_id;
select count(isbn_number2) into l_patisbn2 from patron where user_id = l_user_id;
select txn_id into l_txn from patron where user_id = l_user_id;
  
  if l_patisbn = 0 THEN
    UPDATE PATRON
    SET ISBN_NUMBER = l_isbn
    WHERE l_user_id = user_id;
  elsif l_patisbn2 = 0 THEN 
    UPDATE PATRON
    SET ISBN_NUMBER2 = l_isbn
    WHERE l_user_id = user_id; 
  else
     RAISE_APPLICATION_ERROR(-20211, 'ERROR!');
  end if;
  
  select count(book1_isbn), count(book2_isbn) into l_book,l_book2 from transactions where txn_id = l_txn;
  
  if l_book = 0 THEN
    UPDATE transactions
    SET book1_isbn = l_isbn,
    book1_status = 'ON HOLD',
    book1_date = SYSDATE,
    book1_due = SYSDATE+7,
    book1_charge = 0
    WHERE txn_id = l_txn;
  elsif l_book2 = 0 THEN
    UPDATE transactions
    SET book2_isbn = l_isbn,
    book2_status = 'ON HOLD',
    book2_date = SYSDATE,
    book2_due = SYSDATE+7,
    book2_charge = 0
    WHERE txn_id = l_txn;
  else
    RAISE_APPLICATION_ERROR(-20211, 'ERROR!');
  end if;
  
  UPDATE BOOK
  SET remaining = remaining - 1
  WHERE isbn_number = l_isbn;
  
  select remaining into l_check from book where isbn_number = l_isbn;
  
  if l_check = 0 then
  
  UPDATE BOOK 
  set status = 'NOT AVAILABLE'
  where isbn_number = l_isbn;
  
  end if;
  
  


END;

/
