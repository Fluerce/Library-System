/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Forms;

import Database.JavaConnectDB;
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class AddShelfFrame extends javax.swing.JFrame {

    Connection con;
    OraclePreparedStatement ps;
    OracleResultSet rs;
    CallableStatement cs;
    
    public AddShelfFrame() throws FontFormatException, IOException{
        initComponents();
        InputStream is = getClass().getResourceAsStream("/Fonts/Crayon.ttf");
        Font font = Font.createFont(Font.TRUETYPE_FONT, is);
        capTF.setFont(font.deriveFont(20f));
        con = JavaConnectDB.ConnectDB();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        capTF = new javax.swing.JTextField();
        confirmButton = new javax.swing.JButton();
        backButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(360, 360));
        setResizable(false);
        getContentPane().setLayout(null);

        capTF.setForeground(new java.awt.Color(255, 255, 255));
        capTF.setToolTipText("");
        capTF.setBorder(null);
        capTF.setOpaque(false);
        getContentPane().add(capTF);
        capTF.setBounds(30, 190, 300, 30);

        confirmButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/confirmbutton.png"))); // NOI18N
        confirmButton.setBorder(null);
        confirmButton.setBorderPainted(false);
        confirmButton.setContentAreaFilled(false);
        confirmButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                confirmButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                confirmButtonMouseExited(evt);
            }
        });
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });
        getContentPane().add(confirmButton);
        confirmButton.setBounds(20, 250, 160, 70);

        backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/back2button.png"))); // NOI18N
        backButton.setBorder(null);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                backButtonMouseExited(evt);
            }
        });
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        getContentPane().add(backButton);
        backButton.setBounds(190, 250, 150, 70);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/addshelfpop.png"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 360, 350);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void confirmButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/confirmbuttonclicked.png"));
        confirmButton.setIcon(cn);  
    }//GEN-LAST:event_confirmButtonMouseEntered

    private void confirmButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_confirmButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/confirmbutton.png"));
        confirmButton.setIcon(cn);
    }//GEN-LAST:event_confirmButtonMouseExited

    private void backButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/back2buttonclicked.png"));
        backButton.setIcon(cn);
    }//GEN-LAST:event_backButtonMouseEntered

    private void backButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/back2button.png"));
        backButton.setIcon(cn);
    }//GEN-LAST:event_backButtonMouseExited

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        back();
    }//GEN-LAST:event_backButtonActionPerformed

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
        if(!(capTF.getText().equals("") && !new menuDBAlgo().isNumber(capTF.getText()))){
            try {
                cs = con.prepareCall("{call addshelf(" + capTF.getText() +")}");
                cs.execute();
                JOptionPane.showMessageDialog(null, "Added Shelf! Reclick Button to Update!", "SUCCESS", 1);
            } catch (SQLException ex) {
                Logger.getLogger(AddShelfFrame.class.getName()).log(Level.SEVERE, null, ex);
            }  
        }else
            JOptionPane.showMessageDialog(null, "Invalid Input!", "FAILED", 0);
    }//GEN-LAST:event_confirmButtonActionPerformed

    private void back(){
        this.dispose();
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JTextField capTF;
    private javax.swing.JButton confirmButton;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
