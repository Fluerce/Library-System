package Forms;

import Database.JavaConnectDB;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class menuDBAlgo {
    
    Connection con;
    OraclePreparedStatement ps;
    OracleResultSet rs;
    CallableStatement cs;
    
    public menuDBAlgo(){
        con = JavaConnectDB.ConnectDB();
    }
    
    public void nameEdit(JTextField TF, int i) throws SQLException{
        if(isEmpty(TF)){
            JOptionPane.showMessageDialog(null, "ERROR!", "EDIT FAILED", 0);
        }else{
            cs = con.prepareCall("{call editname('" + TF.getText() + "'," + i + ")}");
            cs.execute();
            JOptionPane.showMessageDialog(null, "Name Changed! Log-in again to update!", "SUCCESS", 1);    
        }
    }
    
    public void addressEdit(JTextField TF, int i) throws SQLException{
        if(isEmpty(TF)){
            JOptionPane.showMessageDialog(null, "ERROR!", "EDIT FAILED", 0);
        }else{
            cs = con.prepareCall("{call editaddress('" + TF.getText() + "'," + i + ")}");
            cs.execute();
            JOptionPane.showMessageDialog(null, "Address Changed! Log-in again to update!", "SUCCESS", 1);
        }    
    }
    
    public void passEdit(JTextField TF, int i) throws SQLException{
        if(isEmpty(TF)){
            JOptionPane.showMessageDialog(null, "ERROR!", "EDIT FAILED", 0);
        }else{
            cs = con.prepareCall("{call editpass('" + TF.getText() + "'," + i + ")}");
            cs.execute();
            JOptionPane.showMessageDialog(null, "Password Changed! Log-in again to update!", "SUCCESS", 1);
        }  
    }
    
    public void startShelf(JTable table, DefaultTableModel model) throws SQLException{
        model.setRowCount(0);
        String sql = "select * FROM SHELF ORDER BY SHELF_ID";
        String num,quan,capa;
        ps = (OraclePreparedStatement) con.prepareStatement(sql);
        rs = (OracleResultSet) ps.executeQuery();
        while(rs.next()){
            num = rs.getString(1);
            quan = rs.getString(3);
            capa = rs.getString(2);
            model.addRow(new Object[]{num,quan,capa});
        }
    }
    
    public void startBooks(JTable table, DefaultTableModel model) throws SQLException{
        model.setRowCount(0);
        String sql = "SELECT isbn_number,book_title,year_published,copy_number,shelf_id, author_name \n" +
        "FROM BOOK JOIN AUTHOR ON author.author_id = BOOK.AUTHOR_ID ORDER BY SHELF_ID";
        String isbn,author,title,year,copy,shelf;
        ps = (OraclePreparedStatement) con.prepareStatement(sql);
        rs = (OracleResultSet) ps.executeQuery();
        while(rs.next()){
            isbn = rs.getString(1);
            title = rs.getString(2);
            year = rs.getString(3);
            copy = rs.getString(4);
            shelf = rs.getString(5);
            author = rs.getString(6);
            
            int convert = Integer.parseInt(copy);
            for(int i = 0; i < convert; i++)
                model.addRow(new Object[]{isbn,author,title,year,(i+1),shelf});
        }
    }
    
    public void startBorrow(JTable table, DefaultTableModel model) throws SQLException{
        model.setRowCount(0);
        String sql = "SELECT \n" +
        "book.isbn_number, \n" +
        "author.author_name,\n" +
        "book.book_title\n" +
        "FROM book\n" +
        "JOIN AUTHOR ON Author.author_id = book.author_id WHERE book.STATUS = 'AVAILABLE'";
        String isbn,author,title;
        ps = (OraclePreparedStatement) con.prepareStatement(sql);
        rs = (OracleResultSet) ps.executeQuery();
        while(rs.next()){
           isbn = rs.getString(1);
           title = rs.getString(3);
           author = rs.getString(2);
           model.addRow(new Object[]{isbn,author,title,"On Shelf"});
        }
    }
    
    public void searchButton(JTable table, DefaultTableModel model, JTextField TF) throws SQLException{
        if(TF.getText().equals("")){
            startBorrow(table,model);
        }else{
            model.setRowCount(0);
            String sql = "SELECT \n" +
                        "book.isbn_number, \n" +
                        "author.author_name,\n" +
                        "book.book_title\n" +
                        "FROM book\n" +
                        "JOIN AUTHOR ON Author.author_id = book.author_id WHERE book.STATUS = 'AVAILABLE' AND '" + TF.getText() + "'= book.ISBN_NUMBER";
            String isbn,author,title;
            ps = (OraclePreparedStatement) con.prepareStatement(sql);
            rs = (OracleResultSet) ps.executeQuery();
            while(rs.next()){
               isbn = rs.getString(1);
               title = rs.getString(3);
               author = rs.getString(2);
               model.addRow(new Object[]{isbn,author,title,"On Shelf"});
            }
        }
    }
    
    public void borrowButton(JTable table, DefaultTableModel model, JTable table2, DefaultTableModel model2, int user_id) throws SQLException{
        String x;
        if(table.getSelectedRowCount() < 0 || table.getSelectedRowCount() > 2){
            JOptionPane.showMessageDialog(null, "ERROR!", "FAILED", 0);
        }else{
            int[] index;
            index = table.getSelectedRows();
            
            for(int i = 0; i < index.length; i++){
                x = table.getValueAt(index[i], 0).toString();
                System.out.println(x);
                cs = con.prepareCall("{call borrowbook(" + user_id + ",'" + x + "')}");
                cs.execute();    
            }   
            JOptionPane.showMessageDialog(null, "Borrowed Book! Await for the Librarian to Validate.", "SUCCESS", 1);
            startBorrow(table, model);
            startReturn(table2, model2, user_id);
        }
    }
    
    public void startReturn(JTable table, DefaultTableModel model, int user_id) throws SQLException{
        model.setRowCount(0);
        String sql = "SELECT \n" +
        "book.isbn_number,\n" +
        "book.book_title,\n" +
        "transactions.book1_date,\n" +
        "transactions.book1_due,\n" +
        "transactions.book1_charge, transactions.book1_status\n" +
        "from book join transactions on transactions.book1_isbn = book.ISBN_NUMBER\n" +
        "join patron on patron.TXN_ID = transactions.txn_id where patron.user_id = " + user_id;
        
        String isbn,title,date,due,charge,status;
        ps = (OraclePreparedStatement) con.prepareStatement(sql);
        rs = (OracleResultSet) ps.executeQuery();
        while(rs.next()){
           isbn = rs.getString(1);
           title = rs.getString(2);
           date = rs.getDATE(3).toString();
           due = rs.getDATE(4).toString();
           charge = rs.getString(5);
           status = rs.getString(6);
           
           
           model.addRow(new Object[]{isbn,title,date,due,charge,status});
        }
        
        sql = "SELECT \n" +
        "book.isbn_number,\n" +
        "book.book_title,\n" +
        "transactions.book2_date,\n" +
        "transactions.book2_due,\n" +
        "transactions.book2_charge, transactions.book2_status\n" +
        "from book join transactions on transactions.book2_isbn = book.ISBN_NUMBER\n" +
        "join patron on patron.TXN_ID = transactions.txn_id where patron.user_id = " + user_id;
        
        ps = (OraclePreparedStatement) con.prepareStatement(sql);
        rs = (OracleResultSet) ps.executeQuery();
        while(rs.next()){
           isbn = rs.getString(1);
           title = rs.getString(2);
           date = rs.getDATE(3).toString();
           due = rs.getDATE(4).toString();
           charge = rs.getString(5);
           status = rs.getString(6);
           
           
           model.addRow(new Object[]{isbn,title,date,due,charge,status});
        }
    }
    
    public void columnFixer(JTable table, DefaultTableModel model){
        int x = model.getColumnCount();
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer();
        cellRenderer.setHorizontalAlignment(JLabel.CENTER);
        for(int i = 0; i < x; i++){
            table.getColumnModel().getColumn(i).setMinWidth(250);  
            table.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }
    }
    
    public boolean isEmpty(JTextField TF){
        return TF.getText().equals("");
    }
    
    public boolean isNumber(String s){ 
        for (int i = 0; i < s.length(); i++) 
            if (Character.isDigit(s.charAt(i))  == false) 
                return false; 
  
        return true; 
    }
    
    public int countNum(String s){  
        int count = 0;       
        for(int i = 0; i < s.length(); i++) {    
            if(s.charAt(i) != ' ')    
                count++;    
        }  
        return count;
    }
}
