package Forms;

import Database.JavaConnectDB;
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class RegisterFrame extends javax.swing.JFrame {
    
    int user_id;

    public RegisterFrame() throws FontFormatException, IOException {
        initComponents();
        InputStream is = getClass().getResourceAsStream("/Fonts/Crayon.ttf");
        Font font = Font.createFont(Font.TRUETYPE_FONT, is);
        confirmTF.setFont(font.deriveFont(20f));
        userTF.setFont(font.deriveFont(20f));
        passTF.setFont(font.deriveFont(20f));
        checkBox.setFont(font.deriveFont(20f));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        userTF = new javax.swing.JTextField();
        confirmTF = new javax.swing.JTextField();
        backButton = new javax.swing.JButton();
        passTF = new javax.swing.JTextField();
        signupButton = new javax.swing.JButton();
        checkBox = new javax.swing.JCheckBox();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        userTF.setToolTipText("");
        userTF.setBorder(null);
        userTF.setOpaque(false);
        getContentPane().add(userTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, 190, 40));

        confirmTF.setToolTipText("");
        confirmTF.setBorder(null);
        confirmTF.setOpaque(false);
        getContentPane().add(confirmTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 430, 190, 40));

        backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/backbutton.png"))); // NOI18N
        backButton.setBorder(null);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                backButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                backButtonMouseExited(evt);
            }
        });
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        getContentPane().add(backButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, -1, -1));

        passTF.setToolTipText("");
        passTF.setBorder(null);
        passTF.setOpaque(false);
        getContentPane().add(passTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 340, 190, 40));

        signupButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/registerbutton.png"))); // NOI18N
        signupButton.setBorder(null);
        signupButton.setBorderPainted(false);
        signupButton.setContentAreaFilled(false);
        signupButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                signupButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                signupButtonMouseExited(evt);
            }
        });
        signupButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupButtonActionPerformed(evt);
            }
        });
        getContentPane().add(signupButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, -1, -1));

        checkBox.setForeground(new java.awt.Color(243, 225, 225));
        checkBox.setText("REGISTER AS LIBRARIAN");
        checkBox.setBorder(null);
        checkBox.setContentAreaFilled(false);
        checkBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBoxActionPerformed(evt);
            }
        });
        getContentPane().add(checkBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 560, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/register.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void signupButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/registerbuttonclicked.png"));
        signupButton.setIcon(cn);
    }//GEN-LAST:event_signupButtonMouseEntered

    private void signupButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/registerbutton.png"));
        signupButton.setIcon(cn);
    }//GEN-LAST:event_signupButtonMouseExited

    private void backButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/backbuttonclicked.png"));
        backButton.setIcon(cn);
    }//GEN-LAST:event_backButtonMouseEntered

    private void backButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_backButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/backbutton.png"));
        backButton.setIcon(cn);
    }//GEN-LAST:event_backButtonMouseExited

    private void checkBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkBoxActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        login();
    }//GEN-LAST:event_backButtonActionPerformed

    private void signupButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupButtonActionPerformed
        String username = userTF.getText();
        String pass = passTF.getText();
        String retype = confirmTF.getText();
        
        if(username.equals("") || pass.equals("") || retype.equals(""))
            JOptionPane.showMessageDialog(null, "Please Fill Out All Fields!" , "Register Failed!", JOptionPane.ERROR_MESSAGE);
        else if(!(pass.equalsIgnoreCase(retype)))
            JOptionPane.showMessageDialog(null, "Password Inputs Must Be The Same!" , "Register Failed!", JOptionPane.ERROR_MESSAGE);
        else{
            Connection con;
            OraclePreparedStatement ps;
            OracleResultSet rs = null;
            con = JavaConnectDB.ConnectDB();
            try{
                String sql;
                if(checkBox.isSelected()){
                    sql = "INSERT INTO USERS(user_id,user_name,user_password, user_type) VALUES(user_id_sequence.nextval,'" + username +"','" + pass + "', 'LIBRARIAN')";
                    ps = (OraclePreparedStatement) con.prepareStatement(sql);
                    ps.executeQuery();
                    sql = "INSERT INTO LIBRARIAN VALUES(user_id_sequence.currval,lib_id_sequence.nextval)";
                    ps = (OraclePreparedStatement) con.prepareStatement(sql);     
                    ps.executeQuery();
                }else{
                    sql = "INSERT INTO USERS(user_id,user_name,user_password, user_type) VALUES(user_id_sequence.nextval,'" + username +"','" + pass + "', 'PATRON')";
                    ps = (OraclePreparedStatement) con.prepareStatement(sql);
                    ps.executeQuery();
                }
                
                sql = "INSERT INTO PATRON(user_id) VALUES(user_id_sequence.currval)";
                ps = (OraclePreparedStatement) con.prepareStatement(sql);
                ps.executeQuery();
                
                sql = "SELECT user_id_sequence.currval FROM (SELECT user_id FROM users ORDER BY user_id DESC) WHERE ROWNUM = 1";
                ps = (OraclePreparedStatement) con.prepareStatement(sql);
                ps.executeQuery();
                rs = (OracleResultSet) ps.executeQuery();
                if(rs.next()){
                    user_id = rs.getInt(1);
                    JOptionPane.showMessageDialog(null, "New Account Created!, Your User_ID is: " + user_id , "Register Successfully!", 1);
                }
                
                login();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }
        }   
    }//GEN-LAST:event_signupButtonActionPerformed

    private void login(){
        LoginFrame ui = null;
        try {
            ui = new LoginFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
        this.dispose();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.JCheckBox checkBox;
    private javax.swing.JTextField confirmTF;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField passTF;
    private javax.swing.JButton signupButton;
    private javax.swing.JTextField userTF;
    // End of variables declaration//GEN-END:variables
}
