--------------------------------------------------------
--  File created - Monday-March-09-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure ADDBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."ADDBOOK" (l_isbn VARCHAR2, l_title VARCHAR2, l_author VARCHAR2, l_year NUMBER, l_shelf NUMBER) AS

l_check NUMBER;
l_check3 NUMBER;
l_quantity NUMBER;
l_capacity NUMBER;
l_copy NUMBER;
l_check4 NUMBER;
  
BEGIN


SELECT COUNT(shelf_id) into l_check FROM shelf where shelf_id = l_shelf;

SELECT quantity, capacity_shelf into l_quantity, l_capacity FROM SHELF where shelf_id = l_shelf;

IF l_quantity = l_capacity OR l_check = 0 THEN
  RAISE_APPLICATION_ERROR(-20111, 'Storage Exceeded/ does not exist'); 
ELSE

  SELECT COUNT(isbn_number) into l_copy FROM book where isbn_number = l_isbn;
  IF l_copy = 0 THEN
    select COUNT(author_id) into l_check4 from author where author_name = l_author;
    if l_check4 = 0 THEN
      DBMS_OUTPUT.PUT_LINE('asdasd');
      INSERT INTO BOOK VALUES (l_isbn,l_title,l_year, 1 ,l_shelf,author_id_sequence.nextval,'AVAILABLE',1);
      INSERT INTO AUTHOR VALUES (author_id_sequence.currval, l_author);
    else
      INSERT INTO BOOK VALUES (l_isbn,l_title,l_year, 1 ,l_shelf,l_check4,'AVAILABLE',1);
    end if;
    
  ELSE
    
    UPDATE BOOK
    SET copy_number = copy_number + 1
    WHERE isbn_number = l_isbn;
  END IF;
  
  SELECT shelf_id into l_check3 FROM book where isbn_number = l_isbn;
  
  UPDATE SHELF
  SET Quantity = Quantity + 1
  WHERE SHELF_ID = l_check3;
END IF;

END;

/
--------------------------------------------------------
--  DDL for Procedure ADDSHELF
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."ADDSHELF" (l_cap NUMBER) AS

BEGIN

INSERT INTO SHELF VALUES (shelf_id_sequence.nextval, l_cap, 0);

END;

/
--------------------------------------------------------
--  DDL for Procedure BORROWBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."BORROWBOOK" (l_user_id NUMBER, l_isbn VARCHAR2) AS

l_user NUMBER;
l_txn NUMBER;
l_patisbn VARCHAR2(17);
l_patisbn2 VARCHAR2(17);
l_book VARCHAR2(17);
l_book2 VARCHAR2(17);
l_check NUMBER;

BEGIN

SELECT count(user_id) into l_user from patron where user_id = l_user_id and txn_id is not null;

if l_user = 0 THEN

INSERT INTO TRANSACTIONS VALUES(txn_id_sequence.nextval,l_isbn,null,'ON HOLD',null,SYSDATE,null,SYSDATE+7,null,0,0);

UPDATE PATRON
SET ISBN_NUMBER = l_isbn,
    TXN_ID = txn_id_sequence.currval
WHERE l_user_id = user_id;

end if;

select isbn_number, isbn_number2, txn_id into l_patisbn,l_patisbn2, l_txn from patron where user_id = l_user_id;
  
  if l_patisbn = null THEN
    UPDATE PATRON
    SET ISBN_NUMBER = l_isbn
    WHERE l_user_id = user_id;
  elsif l_patisbn2 != null THEN 
    UPDATE PATRON
    SET ISBN_NUMBER2 = l_isbn
    WHERE l_user_id = user_id; 
  else
     RAISE_APPLICATION_ERROR(-20211, 'ERROR!');
  end if;
  
  select book1_isbn, book2_isbn into l_book,l_book2 from transactions where txn_id = l_txn;
  
  if l_book = null THEN
    UPDATE transactions
    SET book1_isbn = l_isbn,
    book1_status = 'ON HOLD',
    book1_date = SYSDATE,
    book1_due = SYSDATE+7,
    book1_charge = 0
    WHERE txn_id = l_txn;
  elsif l_book2 != null THEN
    UPDATE transactions
    SET book2_isbn = l_isbn,
    book2_status = 'ON HOLD',
    book2_date = SYSDATE,
    book2_due = SYSDATE+7,
    book2_charge = 0
    WHERE txn_id = l_txn;
  else
    RAISE_APPLICATION_ERROR(-20211, 'ERROR!');
  end if;
  
  UPDATE BOOK
  SET remaining = remaining - 1
  WHERE isbn_number = l_isbn;
  
  select remaining into l_check from book where isbn_number = l_isbn;
  
  if l_check = 0 then
  
  UPDATE BOOK 
  set status = 'NOT AVAILABLE'
  where isbn_number = l_isbn;
  
  end if;
  
  


END;

/
--------------------------------------------------------
--  DDL for Procedure DELETEBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."DELETEBOOK" (l_isbn VARCHAR2) AS

l_shelf NUMBER;
l_copy NUMBER;
l_check NUMBER;
l_check2 VARCHAR(20);

BEGIN

select status into l_check2 from book where isbn_number = l_isbn;
if l_check2 = 'NOT AVAILABLE' THEN

  RAISE_APPLICATION_ERROR(-20222, 'BOOK ON TRANSACTION'); 

else
select COUNT(isbn_number) into l_check FROM book where isbn_number = l_isbn;
if l_check != 0 THEN

  select shelf_id into l_shelf FROM book where isbn_number = l_isbn;

  UPDATE BOOK
  SET copy_number = copy_number-1,
      remaining = remaining - 1
  WHERE isbn_number = l_isbn;

  select copy_number into l_copy FROM book where isbn_number = l_isbn;

  if l_copy = 0 THEN
  delete from book where isbn_number = l_isbn;
  end if;

  UPDATE SHELF
  SET Quantity = Quantity - 1
  WHERE SHELF_ID = l_shelf;
  
ELSE

  RAISE_APPLICATION_ERROR(-20222, 'ISBN_NUMBER DOES NOT EXIST'); 

END IF;

end if;

END;

/
--------------------------------------------------------
--  DDL for Procedure EDITADDRESS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITADDRESS" (l_add VARCHAR2, l_id NUMBER) AS 
BEGIN
UPDATE USERS
SET user_address = l_add
WHERE user_id = l_id;
END;

/
--------------------------------------------------------
--  DDL for Procedure EDITBOOK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITBOOK" (l_isbn VARCHAR2, l_title VARCHAR2, l_author VARCHAR2, l_year NUMBER, l_shelf NUMBER) AS

l_check NUMBER;
l_check2 NUMBER;
l_check3 NUMBER;
l_quantity NUMBER;
l_capacity NUMBER;

BEGIN

SELECT copy_number into l_check3 FROM BOOK WHERE ISBN_NUMBER = l_isbn;
SELECT quantity, capacity_shelf into l_quantity, l_capacity FROM SHELF where shelf_id = l_shelf;

IF l_quantity = l_capacity  OR l_quantity + l_check3 > l_capacity THEN
  RAISE_APPLICATION_ERROR(-20111, 'Storage Exceeded'); 
ELSIF l_check = 0 THEN
  RAISE_APPLICATION_ERROR(-20121, 'Shelf ID does not Exits'); 
ELSE
  

  
  
  -- author change
  SELECT COUNT(author_name) into l_check FROM AUTHOR WHERE author_name = l_author;
  IF l_check = 0 THEN
    INSERT INTO AUTHOR VALUES (author_id_sequence.nextval, l_author);
  END IF;
  

  -- update new shelf
  UPDATE SHELF
  SET Quantity = Quantity + l_check3
  WHERE SHELF_ID = l_shelf;
  
  --update old shelf
  Select shelf_id into l_check2 FROM book where isbn_number = l_isbn;
  UPDATE SHELF
  SET Quantity = Quantity - l_check3
  WHERE SHELF_ID = l_check2;
  
    -- book year change
   UPDATE BOOK
   SET book_title = l_title,
      year_published = l_year,
      shelf_id = l_shelf
   WHERE ISBN_NUMBER = l_isbn;
  
END IF;

END;

/
--------------------------------------------------------
--  DDL for Procedure EDITNAME
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITNAME" (l_name VARCHAR2, l_id NUMBER) AS 
BEGIN
UPDATE USERS
SET user_name = l_name
WHERE user_id = l_id;
END;

/
--------------------------------------------------------
--  DDL for Procedure EDITPASS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "LOCALHOST"."EDITPASS" (l_pass VARCHAR2, l_id NUMBER) AS 
BEGIN
UPDATE USERS
SET user_password = l_pass
WHERE user_id = l_id;
END;

/
