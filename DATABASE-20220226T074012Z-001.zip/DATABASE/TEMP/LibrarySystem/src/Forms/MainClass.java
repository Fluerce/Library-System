package Forms;

import java.awt.FontFormatException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainClass {

    public static void main(String[] args) {
        LoginFrame ui = null;
        try {
            ui = new LoginFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
    }
}
