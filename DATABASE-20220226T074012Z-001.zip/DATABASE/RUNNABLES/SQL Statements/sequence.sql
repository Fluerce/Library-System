--------------------------------------------------------
--  File created - Sunday-March-08-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence AUTHOR_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."AUTHOR_ID_SEQUENCE"  MINVALUE 1 MAXVALUE 999999 INCREMENT BY 1 START WITH 5 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LIB_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."LIB_ID_SEQUENCE"  MINVALUE 0 MAXVALUE 999999 INCREMENT BY 1 START WITH 4 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SHELF_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."SHELF_ID_SEQUENCE"  MINVALUE 1 MAXVALUE 99999 INCREMENT BY 1 START WITH 3 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."USER_ID_SEQUENCE"  MINVALUE 2020000000 MAXVALUE 2020999999 INCREMENT BY 1 START WITH 2020000004 NOCACHE  NOORDER  NOCYCLE ;
