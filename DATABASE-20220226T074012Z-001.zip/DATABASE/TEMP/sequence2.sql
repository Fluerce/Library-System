--------------------------------------------------------
--  File created - Monday-March-09-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence AUTHOR_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."AUTHOR_ID_SEQUENCE"  MINVALUE 1 MAXVALUE 999999 INCREMENT BY 1 START WITH 18 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence LIB_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."LIB_ID_SEQUENCE"  MINVALUE 0 MAXVALUE 999999 INCREMENT BY 1 START WITH 4 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SHELF_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."SHELF_ID_SEQUENCE"  MINVALUE 1 MAXVALUE 99999 INCREMENT BY 1 START WITH 3 NOCACHE  NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence TXN_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."TXN_ID_SEQUENCE"  MINVALUE 1 MAXVALUE 999999 INCREMENT BY 1 START WITH 21 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_ID_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LOCALHOST"."USER_ID_SEQUENCE"  MINVALUE 2020000000 MAXVALUE 2020999999 INCREMENT BY 1 START WITH 2020000005 NOCACHE  NOORDER  NOCYCLE ;
