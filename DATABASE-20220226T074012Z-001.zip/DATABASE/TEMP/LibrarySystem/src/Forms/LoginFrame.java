package Forms;

import Database.JavaConnectDB;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.HeadlessException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;

public class LoginFrame extends javax.swing.JFrame {
    
    Connection con;
    OraclePreparedStatement ps;
    OracleResultSet rs;
    int user_id;
    String user_name;
    String user_type;
        

    public LoginFrame() throws FontFormatException, IOException {
        initComponents();
        InputStream is = getClass().getResourceAsStream("/Fonts/Crayon.ttf");
        Font font = Font.createFont(Font.TRUETYPE_FONT, is);
        passTF.setFont(font.deriveFont(20f));
        userTF.setFont(font.deriveFont(20f));
        con = JavaConnectDB.ConnectDB();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        signupButton = new javax.swing.JButton();
        userTF = new javax.swing.JTextField();
        passTF = new javax.swing.JTextField();
        loginButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(460, 630));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        signupButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/signupbutton.png"))); // NOI18N
        signupButton.setBorder(null);
        signupButton.setBorderPainted(false);
        signupButton.setContentAreaFilled(false);
        signupButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                signupButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                signupButtonMouseExited(evt);
            }
        });
        signupButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupButtonActionPerformed(evt);
            }
        });
        getContentPane().add(signupButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 460, 120, 30));

        userTF.setToolTipText("");
        userTF.setBorder(null);
        userTF.setOpaque(false);
        getContentPane().add(userTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 190, 40));

        passTF.setToolTipText("");
        passTF.setBorder(null);
        passTF.setOpaque(false);
        getContentPane().add(passTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 400, 190, 40));

        loginButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/loginbutton.png"))); // NOI18N
        loginButton.setBorderPainted(false);
        loginButton.setContentAreaFilled(false);
        loginButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginButtonMouseExited(evt);
            }
        });
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });
        getContentPane().add(loginButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 500, 150, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/login.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void signupButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/signupbuttonclicked.png"));
        signupButton.setIcon(cn);
    }//GEN-LAST:event_signupButtonMouseEntered

    private void signupButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signupButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/signupbutton.png"));
        signupButton.setIcon(cn);
    }//GEN-LAST:event_signupButtonMouseExited

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        
        int userOnly = 0;
        try{
            
            if(isLibrarian(userTF.getText()))
                userOnly = 1;
            String sql = "Select * from USERS where USER_ID='" + userTF.getText() + "'and USER_PASSWORD='" + passTF.getText() +"'";
            ps = (OraclePreparedStatement) con.prepareStatement(sql);
            rs = (OracleResultSet) ps.executeQuery();
            if(rs.next()){
                user_id = rs.getInt(1);
                user_name = rs.getString(2);
                user_type = rs.getString(6);
                JOptionPane.showMessageDialog(null, "Log in Success!", "Welcome Back!", 1);
                MenuFrame ui = null;
                try {
                    ui = new MenuFrame(user_id,user_name,user_type);
                } catch (FontFormatException | IOException ex) {
                    Logger.getLogger(LoginFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
                ui.setVisible(true);
                ui.setLocationRelativeTo(null);
                this.dispose();
            }else
                JOptionPane.showMessageDialog(null, "Log in Failed!", "ERROR", JOptionPane.ERROR_MESSAGE);
            
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(null, "Log in Failed!", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void signupButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupButtonActionPerformed
        RegisterFrame ui = null;
        try {
            ui = new RegisterFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(LoginFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_signupButtonActionPerformed

    private void loginButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/loginbuttonclicked.png"));
        loginButton.setIcon(cn);
    }//GEN-LAST:event_loginButtonMouseEntered

    private void loginButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_loginButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/loginbutton.png"));
        loginButton.setIcon(cn);
    }//GEN-LAST:event_loginButtonMouseExited
    
    private boolean isLibrarian(String user){
        try{
            String sql = "SELECT user_name, users.user_id,"
            + "librarian.LIB_LOGIN_ID FROM USERS "
            + "JOIN librarian ON USERS.USER_ID = librarian.USER_ID "
            + "WHERE user_name = '" + user + "'";
            ps = (OraclePreparedStatement) con.prepareStatement(sql);
            rs = (OracleResultSet) ps.executeQuery();
            return rs.next();
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return false;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton loginButton;
    private javax.swing.JTextField passTF;
    private javax.swing.JButton signupButton;
    private javax.swing.JTextField userTF;
    // End of variables declaration//GEN-END:variables
}
