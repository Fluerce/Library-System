package Forms;

import java.awt.Font;
import java.awt.FontFormatException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class MenuFrame extends javax.swing.JFrame {
    
    boolean account = true;
    boolean borrow = true;
    boolean manage = true;
    boolean transaction = true;
    int user_id;
    menuDBAlgo algo;
    public MenuFrame(int i, String x, String y) throws FontFormatException, IOException, SQLException {
        initComponents();
        InputStream is = getClass().getResourceAsStream("/Fonts/Crayon.ttf");
        Font font = Font.createFont(Font.TRUETYPE_FONT, is);
        userLabel.setFont(font.deriveFont(20f));
        IDLabel.setFont(font.deriveFont(20f));
        typeLabel.setFont(font.deriveFont(20f));
        usernameTF.setFont(font.deriveFont(20f));
        passTF.setFont(font.deriveFont(20f));
        addressTF.setFont(font.deriveFont(20f));
        cardPanel.setVisible(false);
        accountPanel.setVisible(false);
        managePanel.setVisible(false);
        userLabel.setText(x);
        typeLabel.setText(y);
        IDLabel.setText(Integer.toString(i));
        user_id = i;
        algo = new menuDBAlgo();
        algo.columnFixer(manageBookTable, model);
        algo.columnFixer(manageShelfTable, model2);
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        transactionButton = new javax.swing.JButton();
        booksButton = new javax.swing.JButton();
        accountButton = new javax.swing.JButton();
        manageButton = new javax.swing.JButton();
        userLabel = new javax.swing.JLabel();
        cardPanel = new javax.swing.JPanel();
        accountPanel = new javax.swing.JPanel();
        addressEdit = new javax.swing.JButton();
        passEdit = new javax.swing.JButton();
        nameEdit = new javax.swing.JButton();
        addressTF = new javax.swing.JTextField();
        passTF = new javax.swing.JTextField();
        usernameTF = new javax.swing.JTextField();
        typeLabel = new javax.swing.JLabel();
        IDLabel = new javax.swing.JLabel();
        logoutButton = new javax.swing.JButton();
        bgAccount = new javax.swing.JLabel();
        managePanel = new javax.swing.JPanel();
        shelfButton = new javax.swing.JButton();
        editButton = new javax.swing.JButton();
        deleteButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        manageBookTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        manageShelfTable = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        bg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        transactionButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/transactionbutton.png"))); // NOI18N
        transactionButton.setBorder(null);
        transactionButton.setBorderPainted(false);
        transactionButton.setContentAreaFilled(false);
        transactionButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                transactionButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                transactionButtonMouseExited(evt);
            }
        });
        transactionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                transactionButtonActionPerformed(evt);
            }
        });
        getContentPane().add(transactionButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, -1, -1));

        booksButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/borrowbutton.png"))); // NOI18N
        booksButton.setBorder(null);
        booksButton.setBorderPainted(false);
        booksButton.setContentAreaFilled(false);
        booksButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                booksButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                booksButtonMouseExited(evt);
            }
        });
        booksButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                booksButtonActionPerformed(evt);
            }
        });
        getContentPane().add(booksButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, -1, -1));

        accountButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/accountbutton.png"))); // NOI18N
        accountButton.setBorder(null);
        accountButton.setBorderPainted(false);
        accountButton.setContentAreaFilled(false);
        accountButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                accountButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                accountButtonMouseExited(evt);
            }
        });
        accountButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accountButtonActionPerformed(evt);
            }
        });
        getContentPane().add(accountButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, -1, -1));

        manageButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/managebutton.png"))); // NOI18N
        manageButton.setBorder(null);
        manageButton.setBorderPainted(false);
        manageButton.setContentAreaFilled(false);
        manageButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                manageButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                manageButtonMouseExited(evt);
            }
        });
        manageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manageButtonActionPerformed(evt);
            }
        });
        getContentPane().add(manageButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, -1, -1));
        getContentPane().add(userLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 150, 40));

        cardPanel.setOpaque(false);
        cardPanel.setLayout(new java.awt.CardLayout());

        accountPanel.setOpaque(false);
        accountPanel.setLayout(null);

        addressEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/editbutton.png"))); // NOI18N
        addressEdit.setBorder(null);
        addressEdit.setBorderPainted(false);
        addressEdit.setContentAreaFilled(false);
        addressEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addressEditMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addressEditMouseExited(evt);
            }
        });
        addressEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressEditActionPerformed(evt);
            }
        });
        accountPanel.add(addressEdit);
        addressEdit.setBounds(540, 520, 180, 70);

        passEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/editbutton.png"))); // NOI18N
        passEdit.setBorder(null);
        passEdit.setBorderPainted(false);
        passEdit.setContentAreaFilled(false);
        passEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                passEditMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                passEditMouseExited(evt);
            }
        });
        passEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passEditActionPerformed(evt);
            }
        });
        accountPanel.add(passEdit);
        passEdit.setBounds(540, 650, 180, 70);

        nameEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/editbutton.png"))); // NOI18N
        nameEdit.setBorder(null);
        nameEdit.setBorderPainted(false);
        nameEdit.setContentAreaFilled(false);
        nameEdit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nameEditMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                nameEditMouseExited(evt);
            }
        });
        nameEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameEditActionPerformed(evt);
            }
        });
        accountPanel.add(nameEdit);
        nameEdit.setBounds(540, 390, 180, 70);

        addressTF.setForeground(new java.awt.Color(255, 255, 255));
        addressTF.setBorder(null);
        addressTF.setOpaque(false);
        accountPanel.add(addressTF);
        addressTF.setBounds(330, 550, 160, 30);

        passTF.setForeground(new java.awt.Color(255, 255, 255));
        passTF.setBorder(null);
        passTF.setOpaque(false);
        passTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passTFActionPerformed(evt);
            }
        });
        accountPanel.add(passTF);
        passTF.setBounds(330, 680, 160, 30);

        usernameTF.setForeground(new java.awt.Color(255, 255, 255));
        usernameTF.setBorder(null);
        usernameTF.setOpaque(false);
        accountPanel.add(usernameTF);
        usernameTF.setBounds(330, 410, 160, 30);

        typeLabel.setForeground(new java.awt.Color(255, 255, 255));
        accountPanel.add(typeLabel);
        typeLabel.setBounds(560, 190, 160, 50);

        IDLabel.setForeground(new java.awt.Color(255, 255, 255));
        accountPanel.add(IDLabel);
        IDLabel.setBounds(190, 190, 160, 50);

        logoutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/logoutbutton.png"))); // NOI18N
        logoutButton.setBorder(null);
        logoutButton.setBorderPainted(false);
        logoutButton.setContentAreaFilled(false);
        logoutButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                logoutButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                logoutButtonMouseExited(evt);
            }
        });
        logoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutButtonActionPerformed(evt);
            }
        });
        accountPanel.add(logoutButton);
        logoutButton.setBounds(550, 720, 160, 70);

        bgAccount.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/accountsettings.jpg"))); // NOI18N
        accountPanel.add(bgAccount);
        bgAccount.setBounds(0, 0, 800, 800);

        cardPanel.add(accountPanel, "card2");

        managePanel.setLayout(null);

        shelfButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/smalladdbutton.png"))); // NOI18N
        shelfButton.setBorder(null);
        shelfButton.setBorderPainted(false);
        shelfButton.setContentAreaFilled(false);
        shelfButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                shelfButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                shelfButtonMouseExited(evt);
            }
        });
        shelfButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shelfButtonActionPerformed(evt);
            }
        });
        managePanel.add(shelfButton);
        shelfButton.setBounds(230, 210, 90, 39);

        editButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/smalleditbutton.png"))); // NOI18N
        editButton.setBorder(null);
        editButton.setBorderPainted(false);
        editButton.setContentAreaFilled(false);
        editButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                editButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                editButtonMouseExited(evt);
            }
        });
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });
        managePanel.add(editButton);
        editButton.setBounds(590, 210, 90, 39);

        deleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/smalldeletebutton.png"))); // NOI18N
        deleteButton.setBorder(null);
        deleteButton.setBorderPainted(false);
        deleteButton.setContentAreaFilled(false);
        deleteButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                deleteButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                deleteButtonMouseExited(evt);
            }
        });
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });
        managePanel.add(deleteButton);
        deleteButton.setBounds(680, 210, 90, 39);

        addButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/smalladdbutton.png"))); // NOI18N
        addButton.setBorder(null);
        addButton.setBorderPainted(false);
        addButton.setContentAreaFilled(false);
        addButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addButtonMouseExited(evt);
            }
        });
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        managePanel.add(addButton);
        addButton.setBounds(500, 210, 90, 39);

        jScrollPane1.setBackground(new java.awt.Color(1, 71, 68));

        manageBookTable.setBackground(new java.awt.Color(1, 71, 68));
        Object[] columns = {"ISBN Number","Author","Book Title"
            ,"Year Published","Copy Number","Shelf Number", "Status","Borrowed By"};
        model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        manageBookTable.setForeground(new java.awt.Color(255, 255, 255));
        manageBookTable.setModel(model);
        manageBookTable.setFocusable(false);
        manageBookTable.setRowSelectionAllowed(false);
        manageBookTable.getTableHeader().setResizingAllowed(false);
        manageBookTable.getTableHeader().setReorderingAllowed(false);
        manageBookTable.setAutoResizeMode( JTable.AUTO_RESIZE_OFF );
        jScrollPane1.setViewportView(manageBookTable);

        managePanel.add(jScrollPane1);
        jScrollPane1.setBounds(370, 310, 360, 400);

        jScrollPane2.setBackground(new java.awt.Color(1, 71, 68));

        manageShelfTable.setBackground(new java.awt.Color(1, 71, 68));
        Object[] columns2 = {"Shelf Number", "Books Stored", "Capacity"};
        model2 = new DefaultTableModel();
        model2.setColumnIdentifiers(columns2);
        manageShelfTable.setForeground(new java.awt.Color(255, 255, 255));
        manageShelfTable.setModel(model2);
        manageShelfTable.setFocusable(false);
        manageShelfTable.getTableHeader().setResizingAllowed(false);
        manageShelfTable.setRowSelectionAllowed(false);
        manageShelfTable.getTableHeader().setReorderingAllowed(false);
        manageShelfTable.setAutoResizeMode( JTable.AUTO_RESIZE_OFF );
        jScrollPane2.setViewportView(manageShelfTable);

        managePanel.add(jScrollPane2);
        jScrollPane2.setBounds(80, 310, 180, 400);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/managebooks.jpg"))); // NOI18N
        managePanel.add(jLabel1);
        jLabel1.setBounds(0, 0, 800, 800);

        cardPanel.add(managePanel, "card3");

        getContentPane().add(cardPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 800, 800));

        bg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/menu.jpg"))); // NOI18N
        getContentPane().add(bg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    //<editor-fold defaultstate="collapsed" desc="FINAL BUTTON DESIGN">
    private void transactionButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transactionButtonMouseEntered
        if(transaction){
            Icon cn = new ImageIcon(getClass().getResource("/Images/transactionbuttonclicked.png"));
            transactionButton.setIcon(cn);
        }
    }//GEN-LAST:event_transactionButtonMouseEntered

    private void transactionButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_transactionButtonMouseExited
        if(transaction){
            Icon cn = new ImageIcon(getClass().getResource("/Images/transactionbutton.png"));
            transactionButton.setIcon(cn);
        }
    }//GEN-LAST:event_transactionButtonMouseExited

    private void booksButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_booksButtonMouseEntered
        if(borrow){
            Icon cn = new ImageIcon(getClass().getResource("/Images/borrowbuttonclicked.png"));
            booksButton.setIcon(cn);
        }
    }//GEN-LAST:event_booksButtonMouseEntered

    private void booksButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_booksButtonMouseExited
        if(borrow){
            Icon cn = new ImageIcon(getClass().getResource("/Images/borrowbutton.png"));
            booksButton.setIcon(cn);
        }
    }//GEN-LAST:event_booksButtonMouseExited

    private void accountButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accountButtonMouseEntered
        if(account){
            Icon cn = new ImageIcon(getClass().getResource("/Images/accountbuttonclicked.png"));
            accountButton.setIcon(cn);
        }
    }//GEN-LAST:event_accountButtonMouseEntered

    private void accountButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_accountButtonMouseExited
        if(account){
            Icon cn = new ImageIcon(getClass().getResource("/Images/accountbutton.png"));
            accountButton.setIcon(cn);
        }
    }//GEN-LAST:event_accountButtonMouseExited

    private void manageButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_manageButtonMouseEntered
        if(manage){
            Icon cn = new ImageIcon(getClass().getResource("/Images/managebuttonclicked.png"));
            manageButton.setIcon(cn);
        }
    }//GEN-LAST:event_manageButtonMouseEntered

    private void manageButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_manageButtonMouseExited
        if(manage){
            Icon cn = new ImageIcon(getClass().getResource("/Images/managebutton.png"));
            manageButton.setIcon(cn);
        }
        
    }//GEN-LAST:event_manageButtonMouseExited
    //</editor-fold>
    
    private void accountButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accountButtonActionPerformed

        Icon cn = new ImageIcon(getClass().getResource("/Images/accountbuttonclicked.png"));
        accountButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/transactionbutton.png"));
        transactionButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/managebutton.png"));
        manageButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/borrowbutton.png"));
        booksButton.setIcon(cn);
        account = false;
        borrow = true;
        manage = true;
        transaction = true;
        
        cardPanel.setVisible(true);
        accountPanel.setVisible(true);
        managePanel.setVisible(false);
    }//GEN-LAST:event_accountButtonActionPerformed

    private void booksButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_booksButtonActionPerformed
        
        Icon cn = new ImageIcon(getClass().getResource("/Images/borrowbuttonclicked.png"));
        booksButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/transactionbutton.png"));
        transactionButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/managebutton.png"));
        manageButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/accountbutton.png"));
        accountButton.setIcon(cn);
        account = true;
        borrow = false;
        manage = true;
        transaction = true;
        
        cardPanel.setVisible(true);
        accountPanel.setVisible(false);
        managePanel.setVisible(false);
    }//GEN-LAST:event_booksButtonActionPerformed

    private void transactionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_transactionButtonActionPerformed
        
        Icon cn = new ImageIcon(getClass().getResource("/Images/transactionbuttonclicked.png"));
        transactionButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/accountbutton.png"));
        accountButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/managebutton.png"));
        manageButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/borrowbutton.png"));
        booksButton.setIcon(cn);
        account = true;
        borrow = true;
        manage = true;
        transaction = false;
        
        cardPanel.setVisible(true);
        accountPanel.setVisible(false);
        managePanel.setVisible(false);
    }//GEN-LAST:event_transactionButtonActionPerformed
    
    
    private void manageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageButtonActionPerformed
        
        Icon cn = new ImageIcon(getClass().getResource("/Images/managebuttonclicked.png"));
        manageButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/transactionbutton.png"));
        transactionButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/accountbutton.png"));
        accountButton.setIcon(cn);
        cn = new ImageIcon(getClass().getResource("/Images/borrowbutton.png"));
        booksButton.setIcon(cn);
        account = true;
        borrow = true;
        manage = false;
        transaction = true;
        
        cardPanel.setVisible(true);
        accountPanel.setVisible(false);
        managePanel.setVisible(true);
        
        try {
            algo.startShelf(manageShelfTable, model2);
            algo.startBooks(manageBookTable, model);
        } catch (SQLException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_manageButtonActionPerformed

    //<editor-fold defaultstate="collapsed" desc="ACCOUNT SETTINGS PANEL">
    private void addressEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressEditActionPerformed
        try {
            new menuDBAlgo().addressEdit(addressTF, user_id);
        } catch (SQLException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addressEditActionPerformed

    private void passEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passEditActionPerformed
        try {
            new menuDBAlgo().passEdit(passTF, user_id);
        } catch (SQLException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_passEditActionPerformed

    private void nameEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameEditActionPerformed
        try {
            new menuDBAlgo().nameEdit(usernameTF, user_id);
        } catch (SQLException ex) {
            Logger.getLogger(MenuFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_nameEditActionPerformed

    private void nameEditMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nameEditMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/editbutton.png"));
        nameEdit.setIcon(cn);
    }//GEN-LAST:event_nameEditMouseExited

    private void nameEditMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nameEditMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/editbuttonclicked.png"));
        nameEdit.setIcon(cn);
    }//GEN-LAST:event_nameEditMouseEntered

    private void passEditMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passEditMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/editbutton.png"));
        passEdit.setIcon(cn);
    }//GEN-LAST:event_passEditMouseExited

    private void passEditMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_passEditMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/editbuttonclicked.png"));
        passEdit.setIcon(cn);
    }//GEN-LAST:event_passEditMouseEntered

    private void addressEditMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addressEditMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/editbutton.png"));
        addressEdit.setIcon(cn);
    }//GEN-LAST:event_addressEditMouseExited

    private void addressEditMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addressEditMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/editbuttonclicked.png"));
        addressEdit.setIcon(cn);
    }//GEN-LAST:event_addressEditMouseEntered

    private void passTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passTFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passTFActionPerformed

    private void logoutButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/logoutbutton.png"));
        logoutButton.setIcon(cn);
    }//GEN-LAST:event_logoutButtonMouseExited

    private void logoutButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/logoutbuttonclicked.png"));
        logoutButton.setIcon(cn);
    }//GEN-LAST:event_logoutButtonMouseEntered

    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutButtonActionPerformed
        int dialogResult = JOptionPane.showConfirmDialog (null, "Confirm Log-Out?","Warning",2);
            if(dialogResult == JOptionPane.YES_OPTION){
            LoginFrame ui = null;
            try {
                ui = new LoginFrame();
            } catch (FontFormatException | IOException ex) {
                Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ui.setVisible(true);
            ui.setLocationRelativeTo(null);
            this.dispose();
        }
    }//GEN-LAST:event_logoutButtonActionPerformed
    //</editor-fold>
    
    
    //<editor-fold defaultstate="collapsed" desc="MANAGE BOOKS PANEL">
    private void shelfButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shelfButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalladdbuttonclicked.png"));
        shelfButton.setIcon(cn);
    }//GEN-LAST:event_shelfButtonMouseEntered

    private void shelfButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shelfButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalladdbutton.png"));
        shelfButton.setIcon(cn);
    }//GEN-LAST:event_shelfButtonMouseExited

    private void addButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalladdbuttonclicked.png"));
        addButton.setIcon(cn);
    }//GEN-LAST:event_addButtonMouseEntered

    private void addButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalladdbutton.png"));
        addButton.setIcon(cn);
    }//GEN-LAST:event_addButtonMouseExited

    private void editButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalleditbuttonclicked.png"));
        editButton.setIcon(cn);
    }//GEN-LAST:event_editButtonMouseEntered

    private void editButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalleditbutton.png"));
        editButton.setIcon(cn);
    }//GEN-LAST:event_editButtonMouseExited

    private void deleteButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteButtonMouseEntered
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalldeletebuttonclicked.png"));
        deleteButton.setIcon(cn);
    }//GEN-LAST:event_deleteButtonMouseEntered

    private void deleteButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteButtonMouseExited
        Icon cn = new ImageIcon(getClass().getResource("/Images/smalldeletebutton.png"));
        deleteButton.setIcon(cn);
    }//GEN-LAST:event_deleteButtonMouseExited

    private void shelfButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shelfButtonActionPerformed
        AddShelfFrame ui = null;
        try {
            ui = new AddShelfFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
    }//GEN-LAST:event_shelfButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        AddBookFrame ui = null;
        try {
            ui = new AddBookFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
    }//GEN-LAST:event_addButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        EditBookFrame ui = null;
        try {
            ui = new EditBookFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
    }//GEN-LAST:event_editButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        DeleteBookFrame ui = null;
        try {
            ui = new DeleteBookFrame();
        } catch (FontFormatException | IOException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        ui.setVisible(true);
        ui.setLocationRelativeTo(null);
    }//GEN-LAST:event_deleteButtonActionPerformed
    //</editor-fold>


    DefaultTableModel model;
    DefaultTableModel model2;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel IDLabel;
    private javax.swing.JButton accountButton;
    private javax.swing.JPanel accountPanel;
    private javax.swing.JButton addButton;
    private javax.swing.JButton addressEdit;
    private javax.swing.JTextField addressTF;
    private javax.swing.JLabel bg;
    private javax.swing.JLabel bgAccount;
    private javax.swing.JButton booksButton;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton editButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton logoutButton;
    private javax.swing.JTable manageBookTable;
    private javax.swing.JButton manageButton;
    private javax.swing.JPanel managePanel;
    private javax.swing.JTable manageShelfTable;
    private javax.swing.JButton nameEdit;
    private javax.swing.JButton passEdit;
    private javax.swing.JTextField passTF;
    private javax.swing.JButton shelfButton;
    private javax.swing.JButton transactionButton;
    private javax.swing.JLabel typeLabel;
    private javax.swing.JLabel userLabel;
    private javax.swing.JTextField usernameTF;
    // End of variables declaration//GEN-END:variables
}
