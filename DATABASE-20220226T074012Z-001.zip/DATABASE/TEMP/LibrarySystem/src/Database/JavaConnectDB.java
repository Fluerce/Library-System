package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class JavaConnectDB {
    
    public static Connection ConnectDB(){
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","localhost","localhost");
            return con;
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No Database Found!", "ERROR", 0);
        }
        return null;
    }
    
}
